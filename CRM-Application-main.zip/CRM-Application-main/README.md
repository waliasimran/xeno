# CRM-Application
CRM (Customer Relationship Management) application using the MERN stack (MongoDB, Express.js, React.js, and Node.js).
